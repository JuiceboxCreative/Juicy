<?php

class ITSEC_Content_Directory_Module_Init extends ITSEC_Module_Init {
	protected $_id   = 'content-directory';
	protected $_name = 'Content Directory';
	protected $_desc = 'Content Directory.';
}
new ITSEC_Content_Directory_Module_Init();
