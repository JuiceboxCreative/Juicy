<?php
// Set up WP CLI
require_once( 'class-itsec-wp-cli.php' );
$itsec_wp_cli = new ITSEC_WP_ClI();
$itsec_wp_cli->run();
