<?php

class ITSEC_Settings_Module_Init extends ITSEC_Module_Init {
	protected $_id   = 'settings';
	protected $_name = 'Settings';
	protected $_desc = 'Settings.';
}
new ITSEC_Settings_Module_Init();
