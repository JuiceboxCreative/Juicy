<?php

class ITSEC_Dashboard_Widget_Module_Init extends ITSEC_Module_Init {
	protected $_id   = 'dashboard-widget';
	protected $_name = 'Dashboard Widget';
	protected $_desc = 'Dashboard Widget.';
}
new ITSEC_Dashboard_Widget_Module_Init();
