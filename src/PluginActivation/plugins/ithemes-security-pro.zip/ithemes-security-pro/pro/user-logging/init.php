<?php

class ITSEC_User_Logging_Module_Init extends ITSEC_Module_Init {
	protected $_id   = 'user-logging';
	protected $_name = 'User Logging';
	protected $_desc = 'User Logging';
}
new ITSEC_User_Logging_Module_Init();
