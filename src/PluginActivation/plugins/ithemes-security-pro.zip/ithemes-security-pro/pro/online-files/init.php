<?php

class ITSEC_Online_Files_Module_Init extends ITSEC_Module_Init {
	protected $_id   = 'online-files';
	protected $_name = 'Online Files';
	protected $_desc = 'Online File Scans';
}
new ITSEC_Online_Files_Module_Init();
