jQuery(document).ready(function($) {
	if ( $.fn.autoNumeric ) {
		$( '.vfb-currency' ).autoNumeric();
	}
});