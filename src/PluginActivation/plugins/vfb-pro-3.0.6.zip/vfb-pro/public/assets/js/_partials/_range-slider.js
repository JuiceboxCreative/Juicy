jQuery(document).ready(function($) {
	if ( $.fn.ionRangeSlider ) {
		$( '.vfb-range-slider' ).ionRangeSlider();
	}
});