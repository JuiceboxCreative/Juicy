jQuery(document).ready(function($) {
	if ( $.fn.iris ) {
		$( '.vfb-color-picker' ).iris();
	}
});