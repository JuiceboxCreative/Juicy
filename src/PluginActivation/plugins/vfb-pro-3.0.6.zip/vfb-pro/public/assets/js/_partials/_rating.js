jQuery(document).ready(function($) {
	if ( $.fn.rating ) {
		$( '.vfb-rating-input' ).rating();
	}
});