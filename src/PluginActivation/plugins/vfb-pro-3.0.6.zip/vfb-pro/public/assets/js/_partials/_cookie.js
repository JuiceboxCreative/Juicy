jQuery(document).ready(function($) {
	if ( $.fn.phoenix ) {
		$( '.vfb-form-control' ).phoenix();
	}
});