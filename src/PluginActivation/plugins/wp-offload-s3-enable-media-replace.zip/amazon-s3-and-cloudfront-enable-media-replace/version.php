<?php
$GLOBALS['aws_meta']['amazon-s3-and-cloudfront-enable-media-replace']['version'] = '1.0.1';
